<footer class="page-footer font-small bg-succes">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="https://mdbootstrap.com/education/bootstrap/">CofiValley.</a>
  </div>
  <!-- Copyright -->

</footer>
