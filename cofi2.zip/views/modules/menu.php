<nav class="navbar navbar-expand-md  justify-content-center align-items-center navbar-light bg-light shadow  bg-white rounded">
  <a class="navbar-brand" href="#">
   <img src="" width="200" height="40" alt="">
 </a>
 <a class="navbar-brand" href="#">
  <img src="" width="200" height="40" alt="">
</a>
<a class="navbar-brand" href="#">
 <img src="" width="200" height="40" alt="">
</a>
  <a class="navbar-brand" href="#">
   <img src="img/brand.png" width="200" height="40" alt="">
 </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item ">
        <a class="nav-link active" href="index.php?action=cuenta">Cuenta</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="index.php?action=perfil">Perfil</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="index.php?action=historial">Historial</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="index.php?action=pagos">Pagos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="index.php?action=retirar">Retirar</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active text-info"     href="index.php?action=comisionista">Comisionista</a>
      </li>
      <div class="mt-20 mt-lg-0 col-lg-3 d-flex flex-wrap justify-content-center justify-content-lg-end align-items-center" data-aos-duration="600" data-aos="fade-down" data-aos-delay="300">
        <ul>
          <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Cerrar sesion
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="#">Cuenta</a>
                <a class="dropdown-item" href="#">Configuracion</a>
                <a class="dropdown-item" href="#">Cerrar sesion</a>
              </div>
                </li>
          </ul>
      </div>
    </ul>
  </div>
</nav>
